package Login_Form;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefac.PageFactoryHotel;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	PageFactoryHotel pfh;
	@Given("^User opens the browser$")
	public void user_opens_the_browser() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/debjchow/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
	}

	@When("^User Enters the correct url to launch the application$")
	public void user_Enters_the_correct_url_to_launch_the_application() throws Throwable 
	{
		driver.get("C:/Users/debjchow/Desktop/BDD/login.html");
		
	}

	@Then("^verify the title of the login page 'Hotel Booking Application'$")
	public void verify_the_title_of_the_login_page_Hotel_Booking_Application() throws Throwable 
	{
	    String heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
	    assertEquals("Hotel Booking Application",heading);
	    System.out.println("Done");
	    driver.close();
	}

	@Given("^user launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/debjchow/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("C:/Users/debjchow/Desktop/BDD/login.html");
		pfh=new PageFactoryHotel(driver);
	   
	}

	@When("^user enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable 
	{
		pfh.setName(arg1);
		pfh.setPwd(arg2);
	  
	}

	@When("^Clicks on Log in$")
	public void clicks_on_Log_in() throws Throwable 
	{
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^Application takes to the 'Hotel Booking' page$")
	public void application_takes_to_the_Hotel_Booking_page() throws Throwable 
	{
		String heading1=driver.getTitle();
		assertEquals("Hotel Booking", heading1);
		System.out.println("Done1");
		driver.close();
	}
	@When("^user enters the \"([^\"]*)\" and empty password$")
	public void user_enters_the_and_empty_password(String arg1) throws Throwable 
	{
	    pfh.setName(arg1);
	    pfh.setPwd("");
	    driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^show the error message$")
	public void show_the_error_message() throws Throwable 
	{
	    String errormsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
	    assertEquals("* Please enter password.", errormsg);
	    driver.close();
	}
	@When("^user enters the empty username and \"([^\"]*)\"$")
	public void user_enters_the_empty_username_and(String arg1) throws Throwable {
	  pfh.setName("");
	  pfh.setPwd(arg1);
	  driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	  
	}

	@Then("^show the error message for empty username$")
	public void show_the_error_message_for_empty_username() throws Throwable 
	{
		 String errorusrmsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		 assertEquals("* Please enter userName.", errorusrmsg);
		 driver.close();
	}
	@When("^Fill all the details and click confirm booking$")
	public void fill_all_the_details_and_click_confirm_booking() throws Throwable {
	   pfh.setFirstname("Debjit");
	   pfh.setLastname("Roy");
	   pfh.setEmail("debjit@gmail.com");
	   pfh.setNumber("8436127859");
	   pfh.setAddress("Kolkata");
	   pfh.setCities("Bangalore");
	   pfh.setStates("Karnataka");
	   pfh.setNoofpersons("4");
	 
	   pfh.setCardpersonname("Debjit Roy");
	   pfh.setDebitnumber("405011214510");
	   pfh.setCvv1("001");
	   pfh.setExpirationMonth("March");
	   pfh.setExpirationYear("2022");
	  
	   driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^Application takes to the Booking Completed page$")
	public void application_takes_to_the_Booking_Completed_page() throws Throwable {
	 String heading2=driver.getTitle();
	 assertEquals("Payment Details", heading2);
	 Thread.sleep(5000);
	 driver.close();
	}
	@When("^User miss any fields$")
	public void user_miss_any_fields() throws Throwable 
	{
		  pfh.setFirstname("");
		   pfh.setLastname("Roy");
		   pfh.setEmail("debjit@gmail.com");
		   pfh.setNumber("8436127859");
		   pfh.setAddress("Kolkata");
		   pfh.setCities("Bangalore");
		   pfh.setStates("Karnataka");
		   pfh.setNoofpersons("4");
		 
		   pfh.setCardpersonname("Debjit Roy");
		   pfh.setDebitnumber("405011214510");
		   pfh.setCvv1("001");
		   pfh.setExpirationMonth("March");
		   pfh.setExpirationYear("2022");
		   
		   driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		  
	}

	@Then("^Show the error message for empty field$")
	public void show_the_error_message_for_empty_field() throws Throwable 
	{
		String alert=driver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alert);
		Thread.sleep(5000);
		driver.close();
	}

}