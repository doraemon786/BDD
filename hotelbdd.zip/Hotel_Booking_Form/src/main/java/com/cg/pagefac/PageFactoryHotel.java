package com.cg.pagefac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryHotel 
{
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public PageFactoryHotel(WebDriver driver)
	{
		this.driver =driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
       
	}
@FindBy(name="userName")
@CacheLookup
WebElement name;

@FindBy(name="userPwd")
@CacheLookup
WebElement pwd;

@FindBy(id="txtFirstName")
@CacheLookup
WebElement firstname;

@FindBy(id="txtLastName")
@CacheLookup
WebElement lastname;

@FindBy(name="Email")
@CacheLookup
WebElement email;

@FindBy(name="Phone")
@CacheLookup
WebElement number;

@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
@CacheLookup
WebElement address;

@FindBy(name="city")
@CacheLookup
WebElement cities;

@FindBy(name="state")
@CacheLookup
WebElement states;

@FindBy(name="persons")
@CacheLookup
WebElement noofpersons;

@FindBy(xpath="//*[@id=\"rooms\"]")
@CacheLookup
WebElement noofrroms;

@FindBy(id="txtCardholderName")
@CacheLookup
WebElement cardpersonname;

@FindBy(name="debit")
@CacheLookup
WebElement debitnumber;

@FindBy(name="cvv")
@CacheLookup
WebElement cvv1;

@FindBy(id="txtMonth")
@CacheLookup
WebElement expirationMonth;

@FindBy(id="txtYear")
@CacheLookup
WebElement expirationYear;

public WebElement getCardpersonname() {
	return cardpersonname;
}

public void setCardpersonname(String personname) {
	this.cardpersonname.sendKeys(personname);
}

public WebElement getDebitnumber() {
	return debitnumber;
}

public void setDebitnumber(String debitnum) {
	this.debitnumber.sendKeys(debitnum);
}

public WebElement getCvv1() {
	return cvv1;
}

public void setCvv1(String cv) {
	this.cvv1.sendKeys(cv);
}

public WebElement getExpirationMonth() {
	return expirationMonth;
}

public void setExpirationMonth(String expireMonth) {
	this.expirationMonth.sendKeys(expireMonth);
}

public WebElement getExpirationYear() {
	return expirationYear;
}

public void setExpirationYear(String expireYear) {
	this.expirationYear.sendKeys(expireYear);
}

public WebElement getNoofrroms() {
	return noofrroms;
}

public void setNoofrroms(String noofrooms) {
	this.noofrroms.sendKeys(noofrooms);
}

public WebElement getFirstname() {
	return firstname;
}

public void setFirstname(String name) {
	this.firstname.sendKeys(name);
}

public WebElement getLastname() {
	return lastname;
}

public void setLastname(String lname) {
	this.lastname.sendKeys(lname);
}

public WebElement getEmail() {
	return email;
}

public void setEmail(String emai) {
	this.email.sendKeys(emai);
}

public WebElement getNumber() {
	return number;
}

public void setNumber(String num) {
	this.number.sendKeys(num);
}

public WebElement getAddress() {
	return address;
}

public void setAddress(String add) {
	this.address.sendKeys(add);
}

public WebElement getCities() {
	return cities;
}

public void setCities(String cit) {
	Select cities1=new Select(cities);
	cities1.selectByVisibleText(cit);
}

public WebElement getStates() {
	return states;
}

public void setStates(String stat) {
	Select states1=new Select(states);
	states1.selectByVisibleText(stat);
}

public WebElement getNoofpersons() {
	return noofpersons;
}

public void setNoofpersons(String noofper) {
	Select noofpersons1=new Select(noofpersons);
	noofpersons1.selectByVisibleText(noofper);
}



public WebElement getName() {
	return name;
}

public void setName(String username) 
{
   this.name.sendKeys(username);
}

public WebElement getPwd() {
	return pwd;
}

public void setPwd(String password) {
   this.pwd.sendKeys(password);
}


}
