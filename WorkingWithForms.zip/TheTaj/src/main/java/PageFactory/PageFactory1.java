package PageFactory;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactory1
{
	
	WebDriver driver;
	
	@FindBy(name="txtUName")
	@CacheLookup
	WebElement username;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement confirmPassword;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(css="#txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(name="DtOB")
	@CacheLookup
	WebElement DOB;
	
	@FindBy(xpath="//*[@id=\"txtAddress\"]")
	@CacheLookup
	WebElement Address;
	
	@FindBy(css="#txtPhone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(name="gender")
	@CacheLookup
	WebElement Gender;
	
	@FindBy(name="chkHobbies")
	@CacheLookup
	WebElement Hobbies;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword.sendKeys(confirmPassword);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		this.DOB.sendKeys(dOB);
	}

	public WebElement getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address.sendKeys(address);
	}

	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}
	
	public void register_city(String City)
	{
		Select cityVariable=new Select(city);
		cityVariable.selectByValue("Mumbai1");
		
	}
	public void register_gender(String Gender)
	{/*
		Select genderVariable=new Select(GforGender);
		//genderVariable.selectByValue("Male");
		driver.findElement(By.cssSelector("#rbMale")).click();
	*/		
		
		 List<WebElement> radioElem = driver.findElements(By.name("gender"));
         
         for(WebElement webElement : radioElem)
         {
                 String radioSelection;
                 radioSelection = webElement.getAttribute("value").toString();
                 if(radioSelection.equals("Male"))
                 {
                     webElement.click();
                 }
         }
		
		
	}
	public void register_hobbies(String hobbies)
	{
		/*Select hobbiesVariable=new Select(Hobbies);
		hobbiesVariable.selectByValue("Mumbai1");*/
		
		 
        List<WebElement> checkElem = driver.findElements(By.name("chkHobbies"));
        
        for(WebElement webElement : checkElem)
        {
                String checkSelection;
                checkSelection = webElement.getAttribute("value").toString();
                if(checkSelection.equals("Music")||checkSelection.equals("Reading"))
                {
                    webElement.click();
                }
                                        
        }
		
		
	}
	public PageFactory1(WebDriver driver)
	{
		super();
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	

}
