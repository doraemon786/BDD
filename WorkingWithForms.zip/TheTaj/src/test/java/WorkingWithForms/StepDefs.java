package WorkingWithForms;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactory.PageFactory1;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	PageFactory1 page;
	@Given("^User opens the browser and open the webpage$")
	public void user_opens_the_browser_and_open_the_webpage() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/WorkingWithForms.html");
		Thread.sleep(2000);
	
	}

	@When("^User enters all the information correctly$")
	public void user_enters_all_the_information_correctly() throws Throwable
	{
		page=new PageFactory1(driver);
		page.setUsername("harsgaut");
		page.setPassword("llkk");
		page.setConfirmPassword("llkk");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.register_gender("Male");
		page.setDOB("01-01-1996");
		page.setEmail("harshkumargautam96@gmail.com");
		page.setAddress("Kanpur");
		page.register_city("Pune");
		page.setPhone("8860723885");
		page.register_hobbies("Music");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
		Thread.sleep(2000);
	}

	@Then("^submit the form$")
	public void submit_the_form() throws Throwable
	{
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
		Thread.sleep(2000);
		driver.quit();
	}
	
	

	@When("^user enter wrong EmailId$")
	public void user_enter_wrong_EmailId() throws Throwable
	{
		page.setUsername("harsgaut");
		page.setPassword("llkk");
		page.setConfirmPassword("llkk");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.register_gender("Male");
		page.setDOB("01-01-1996");
		page.setEmail("harshkumargautam96gmailcom");
		page.setAddress("Kanpur");
		page.register_city("Pune");
		page.setPhone("8860723885");
		page.register_hobbies("Music");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
		Thread.sleep(2000);
	}
	

	@Then("^show error message$")
	public void show_error_message() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String errorMessage=alert.getText();
		System.out.println(errorMessage);
		alert.accept();
	}

	@When("^different Password$")
	public void different_Password() throws Throwable
	{page.setUsername("harsgaut");
	page.setPassword("llkk");
	page.setConfirmPassword("liufkk");
	page.setFirstName("Harsh");
	page.setLastName("Gautam");
	page.register_gender("Male");
	page.setDOB("01-01-1996");
	page.setEmail("harshkumargautam96@gmail.com");
	page.setAddress("Kanpur");
	page.register_city("Pune");
	page.setPhone("8860723885");
	page.register_hobbies("Music");
	Thread.sleep(2000);
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td/input")).click();
	Thread.sleep(2000);
		
	}
	


}
