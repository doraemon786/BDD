package HotelBooking_Scenario;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbooking.HotelBookingpageFactory;

public class StepDef {

	WebDriver driver;
	private String userName;
	private String userPwd;
	HotelBookingpageFactory pagefactoryobj;
@Given("^User launches the browser$")
public void user_launches_the_browser() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "E:/capgemini/chromedriver.exe");
	driver=new ChromeDriver(); 
}

@When("^User opens the login\\.html$")
public void user_opens_the_login_html() throws Throwable {
	driver.get("file:///C:/Users/admin/Desktop/github%20codes%20capgemini/BDD/BDD/login.html");
}

@Then("^Verify login page url$")
public void verify_login_page_url() throws Throwable {
	String heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
	assertEquals("Hotel Booking Application",heading);
	Thread.sleep(2000);

	 driver.close();
}

@Given("^User launches the browser and opens the application$")
public void user_launches_the_browser_and_opens_the_application() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "E:/capgemini/chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///C:/Users/admin/Desktop/github%20codes%20capgemini/BDD/BDD/login.html");
}

@When("^User enters only username$")
public void user_enters_only_username() throws Throwable {
	driver.findElement(By.name("userName")).sendKeys("Capgemini");
	//driver.findElement(By.name("userPwd")).sendKeys("apg1234");
	Thread.sleep(2000);

	driver.findElement(By.className("btn")).click();
}

@Then("^Show error message(\\d+)$")
public void show_error_message(int arg1) throws Throwable {

	String errmsg= driver.findElement(By.id("pwdErrMsg")).getText();
	String experrmsg="* Please enter password.";
	assertEquals(errmsg,experrmsg);
	driver.close();
}

@When("^User enters only password$")
public void user_enters_only_password() throws Throwable {
	driver.findElement(By.name("userPwd")).sendKeys("capg");
	//driver.findElement(By.name("userPwd")).sendKeys("apg1234");
	Thread.sleep(2000);

	driver.findElement(By.className("btn")).click();
}

@Then("^Display error message(\\d+)$")
public void display_error_message(int arg1) throws Throwable {
	String errmsg= driver.findElement(By.id("userErrMsg")).getText();
	String experrmsg="* Please enter userName.";
	assertEquals(errmsg,experrmsg);
	driver.close();
}

@Given("^User has the valid username and passowrd$")
public void user_has_the_valid_username_and_passowrd() throws Throwable {
	userName="capgemini";
	userPwd="capg1234";
}

@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
public void user_enters_the_and(String arg1, String arg2) throws Throwable {
	driver.findElement(By.name("userName")).sendKeys(arg1);
	driver.findElement(By.name("userPwd")).sendKeys(arg2);
	Thread.sleep(2000);
	driver.findElement(By.className("btn")).click();
	Thread.sleep(2000);
	//driver.close();
}

@Then("^Application takes to the 'Hotel Booking' page$")
public void application_takes_to_the_Hotel_Booking_page() throws Throwable {
	String title=driver.getTitle();
	System.out.println(title);
	assertEquals(title, "Hotel Booking");
	driver.close();
}

@Given("^User is on the Hotel Booking Form$")
public void user_is_on_the_Hotel_Booking_Form() throws Throwable {
	// Write code here that turns the phrase above into concrete actions
	pagefactoryobj = new HotelBookingpageFactory(driver);

	System.setProperty("webdriver.chrome.driver", "E:/capgemini/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("file:///C:/Users/admin/Desktop/github%20codes%20capgemini/BDD/BDD/login.html");

}

@When("^User Fills all the details correctly$")
public void user_Fills_all_the_details_correctly() throws Throwable {
	// Write code here that turns the phrase above into concrete actions
	driver.get("file:///C:/Users/admin/Desktop/github%20codes%20capgemini/BDD/BDD/hotelbooking.html");
	pagefactoryobj = new HotelBookingpageFactory(driver);

	pagefactoryobj.setFormfirstname("Yashi");
	// Thread.sleep(500);
	// driver.close();
	pagefactoryobj.setFormlastname("Sinha");
	pagefactoryobj.setFormemail("ys@gmail.com");
	pagefactoryobj.setFormfone("9453954144");
	pagefactoryobj.setFormaddress("BluntSquare,Pune");
	pagefactoryobj.setFormcity("Pune");
	pagefactoryobj.setFormstate("Maharashtra");
	pagefactoryobj.setFormnoofpersons("3");
	pagefactoryobj.setFormcardholdername("Yashi S");
	pagefactoryobj.setFormdebitCardno("13459045872");
	pagefactoryobj.setFormCVV("123");
	pagefactoryobj.setFormexpmonth("Dec");
	pagefactoryobj.setFormexpyear("2019");

	driver.findElement(By.id("btnPayment")).click();
	Thread.sleep(5000);

}

@Then("^It shows te success message$")
public void it_shows_te_success_message() throws Throwable {
	// Write code here that turns the phrase above into concrete actions
	String actualmsg = pagefactoryobj.getsuccessmsg();
	String expectedmsg = "Booking Completed!";
	assertEquals(actualmsg, expectedmsg);
	driver.close();

}


}
