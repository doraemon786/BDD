package userInformation;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import userInformationPageFactory.InfoPageFactory;

public class StepDef {

	WebDriver driver;
	InfoPageFactory page;
	@Given("^Launch the browser$")
	public void launch_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
	}

	@When("^Open UserInformation\\.html page$")
	public void open_UserInformation_html_page() throws Throwable {
	  driver.get("file:///C:/Users/aakbhatn/Desktop/M3/UserInformation.html");
	}

	@Then("^Verify Title$")
	public void verify_Title() throws Throwable {
	  String title=driver.getTitle();
	  assertEquals("PAN CARD: User Information", title);
	  System.out.println("The Title of the page is"+title);
	  driver.close();
	}

	@When("^Click on submit without entering Applicant name$")
	public void click_on_submit_without_entering_Applicant_name() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("");
		page.ClickBtn();
		//Thread.sleep(2000);
	}

	@Then("^Get alert box message as Please fill applicant name$")
	public void get_alert_box_message_as_Please_fill_applicant_name() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the Applicant Name ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();

		 

	}

	@When("^Click on submit without entering firstName$")
	public void click_on_submit_without_entering_firstName() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("");
		page.ClickBtn();
		
	}

	@Then("^Get alert box message as Please fill firstName$")
	public void get_alert_box_message_as_Please_fill_firstName() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the First Name ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering lastName$")
	public void click_on_submit_without_entering_lastName() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("");
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill lastName$")
	public void get_alert_box_message_as_Please_fill_lastName() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the Last Name ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering fatherName$")
	public void click_on_submit_without_entering_fatherName() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("");
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill fatherName$")
	public void get_alert_box_message_as_Please_fill_fatherName() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the Father Name ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}
	
	@When("^Click on submit without entering DOB$")
	public void click_on_submit_without_entering_DOB() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("");
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill DOB$")
	public void get_alert_box_message_as_Please_fill_DOB() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the DOB", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}
	
	@When("^Click on submit without entering Gender$")
	public void click_on_submit_without_entering_Gender() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill Gender$")
	public void get_alert_box_message_as_Please_fill_Gender() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please select the Gender", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering mobile no\\.$")
	public void click_on_submit_without_entering_mobile_no() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		driver.findElement(By.xpath("//*[@id=\"rdbMale\"]")).click();
		page.setMobNo("");
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill mobile no\\.$")
	public void get_alert_box_message_as_Please_fill_mobile_no() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill Mobile no", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering email$")
	public void click_on_submit_without_entering_email() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		driver.findElement(By.xpath("//*[@id=\"rdbMale\"]")).click();
		page.setMobNo("9044964433");
		page.setEmail("");
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill email$")
	public void get_alert_box_message_as_Please_fill_email() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the Email id ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering Landline$")
	public void click_on_submit_without_entering_Landline() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		driver.findElement(By.xpath("//*[@id=\"rdbMale\"]")).click();
		page.setMobNo("9044964433");
		page.setEmail("aakarsh.bh@gmail.com");
		page.setLandline("");
		page.ClickBtn();
	}
	
	@Then("^Get alert box message as Please fill Landline$")
	public void get_alert_box_message_as_Please_fill_Landline() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("please fill the landline no", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Click on submit without entering Communication$")
	public void click_on_submit_without_entering_Communication() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		driver.findElement(By.xpath("//*[@id=\"rdbMale\"]")).click();
		page.setMobNo("9044964433");
		page.setEmail("aakarsh.bh@gmail.com");
		page.setLandline("0522336699");
		
		page.ClickBtn();
	}

	@Then("^Get alert box message as Please fill Communication$")
	public void get_alert_box_message_as_Please_fill_Communication() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please select the Type of Communication ", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		driver.close();
	}

	@When("^Fill details correctly$")
	public void fill_details_correctly() throws Throwable {
		page=new InfoPageFactory(driver);
		page.setApplicantname("Aakarsh");
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setFathername("Shalabh");
		page.setDOB("20-12-1995");
		driver.findElement(By.xpath("//*[@id=\"rdbMale\"]")).click();
		page.setMobNo("9044964433");
		page.setEmail("aakarsh.bh@gmail.com");
		page.setLandline("0522336699");
		driver.findElement(By.xpath("//*[@id=\"rdbOfficeAdd\"]")).click();
		page.setAddress("Lucknow");
		page.ClickBtn();
	}

	@Then("^verify the alert box message and verify going on the next page$")
	public void verify_the_alert_box_message_and_verify_going_on_the_next_page() throws Throwable {
		
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Personal details are validated.", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		//Thread.sleep(2000);
		alert.accept();
		//Thread.sleep(2000);
		 String title=driver.getTitle();
		  assertEquals("Payment Details", title);
		  System.out.println("The Title of the page is"+title);
		 
		driver.close();
	}






}
