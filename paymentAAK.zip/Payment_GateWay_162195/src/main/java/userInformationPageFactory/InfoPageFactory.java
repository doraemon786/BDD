package userInformationPageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class InfoPageFactory {

	WebDriver driver;
	public InfoPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"txtName\"]")
	@CacheLookup
	WebElement applicantname;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstname;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fathername;
	
	@FindBy(name="txtDOB")
	@CacheLookup
	WebElement DOB;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[7]/td[2]")
	@CacheLookup
	WebElement gender;
	
	@FindBy(id="txtMobileNo")
	@CacheLookup
	WebElement MobNo;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	@CacheLookup
	WebElement email;
	
	@FindBy(css="#txtLndLine")
	@CacheLookup
	WebElement landline;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td[2]")
	@CacheLookup
	WebElement communication;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement address;
	
	
	
	
	
	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getApplicantname() {
		return applicantname;
	}

	public void setApplicantname(String applicantname) {
		this.applicantname.sendKeys(applicantname);
	}
	

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}
	
	

	public WebElement getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername.sendKeys(fathername);

	}
	
	

	public WebElement getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		this.DOB.sendKeys(dOB);
	}
	
	 public void selectGender(String gender)
     {
         Select gen = new Select(this.gender);
         gen.selectByValue(gender);
     }
	 
	 public void selectComm(String communication )
     {
         Select gen = new Select(this.communication);
         gen.selectByValue(communication);
     }
	 
	 
	 
	 
	

	public WebElement getMobNo() {
		return MobNo;
	}

	public void setMobNo(String mobNo) {
		this.MobNo.sendKeys(mobNo);
	}
	
	

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	
	

	public WebElement getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline.sendKeys(landline);
	}
	
	

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	@FindBy(id="btnSubmit")
	@CacheLookup
	WebElement submit;
	
public void ClickBtn() {
		
		submit.click();
	}
}
