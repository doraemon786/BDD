package com.cg.maven;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrationForm {

	public static void main(String[] args) throws InterruptedException 


	{

		WebElement element;
		System.setProperty("webdriver.chrome.driver", "C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");

		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/harsgaut/Downloads/WorkingWithForms.html");
		driver.manage().window().maximize();

		Thread.sleep(1000);
		driver.findElement(By.id("txtUserName")).sendKeys("harsgaut");
		driver.findElement(By.id("txtPassword")).sendKeys("JDK1.8");
		driver.findElement(By.xpath("//*[@id=\"txtConfPassword\"]")).sendKeys("JDK1.8");
		driver.findElement(By.cssSelector("#txtFirstName")).sendKeys("Harsh");
		driver.findElement(By.name("txtLN")).sendKeys("Gautam");

		List<WebElement> radioElement=driver.findElements(By.name("gender"));
		for(WebElement we: radioElement)
		{
			String selection=we.getAttribute("value").toString();
			if(selection.equals("Male"))
			{
				we.click();
			}

		}
		driver.findElement(By.cssSelector("#DOB")).sendKeys("07-01-1996");
		driver.findElement(By.id("txtEmail")).sendKeys("harshkumargautam96@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"txtAddress\"]")).sendKeys("Mumbai");
		Select city=new Select(driver.findElement(By.name("City")));
		city.selectByIndex(2);
		driver.findElement(By.id("txtPhone")).sendKeys("8860723885");

		List<WebElement>checkBox=driver.findElements(By.name("chkHobbies"));
		for(WebElement we:checkBox)
		{

			String checkBoxSelection=we.getAttribute("value").toString();
			if(checkBoxSelection.equals("Music")||checkBoxSelection.equals("Reading"))
			{
				we.click();
			}
		}
		driver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(13) > td > input[type=\"submit\"]")).click();
		Thread.sleep(3000);
		
		Alert alert=driver.switchTo().alert();
		System.out.println("The message is"+alert.getText());
		alert.accept();
		Thread.sleep(2000);
		driver.quit();
	}

}
