package com.cg.maven;

public class Login 
{
	
	public static void main(String[] args)
	{
		
	}

}
