import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegistrationCaseStudy
{
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");

		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/harsgaut/Downloads/WorkingWithForms.html");
		driver.manage().window().maximize();


		WebElement searchBox=driver.findElement(By.cssSelector("#txtUserName"));
		searchBox.sendKeys("harsgaut");


		WebElement searchBox2=driver.findElement(By.cssSelector("#txtPassword"));
		searchBox2.sendKeys("Nothingtodo");

		WebElement searchBox22=driver.findElement(By.cssSelector("#txtConfPassword"));
		searchBox22.sendKeys("Nothingtodo");

		WebElement searchBox3=driver.findElement(By.cssSelector("#txtFirstName"));
		searchBox3.sendKeys("Harsh");

		WebElement searchBox4=driver.findElement(By.cssSelector("#txtLastName"));
		searchBox4.sendKeys("Kumar Gautam");

		driver.findElement(By.cssSelector("#rbMale")).click();

		WebElement searchBox6=driver.findElement(By.cssSelector("#DOB"));
		searchBox6.sendKeys("31-07-1996");

		WebElement searchBox7=driver.findElement(By.cssSelector("#txtEmail"));
		searchBox7.sendKeys("harshkumargautam96@gmail.com");

		WebElement searchBox8=driver.findElement(By.cssSelector("#txtAddress"));
		searchBox8.sendKeys("Ghaziabad");

		driver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(10) > td:nth-child(2) > select > option:nth-child(1)")).click();

		WebElement searchBox10=driver.findElement(By.cssSelector("#txtPhone"));
		searchBox10.sendKeys("8860723885");

		driver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(12) > td:nth-child(2) > input[type=\"checkbox\"]:nth-child(1)")).click();



		driver.findElement(By.name("submit")).click();
		Thread.sleep(2500);
		
		Alert alert= driver.switchTo().alert();
		System.out.println("Alert msg is :" + alert.getText());
		alert.accept();
		Thread.sleep(2000);
		driver.quit();
		

	}
}