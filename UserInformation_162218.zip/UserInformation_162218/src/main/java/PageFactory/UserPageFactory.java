package PageFactory;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserPageFactory 
{
	WebDriver driver;
	public UserPageFactory(WebDriver driver)
	{
		super();
		this.driver=driver;
		PageFactory.initElements(driver, this);		
	}


	@FindBy(name="txtNM")
	@CacheLookup
	WebElement applicantName;

	@FindBy(name="txtFName")
	@CacheLookup
	WebElement firstName;


	@FindBy(name="txtLName")
	@CacheLookup
	WebElement lastName;

	@FindBy(id="txtFatherName")
	@CacheLookup
	WebElement fatherName;


	@FindBy(id="txtDOB")
	@CacheLookup
	WebElement DOB;

	@FindBy(css="#txtMobileNo")
	@CacheLookup
	WebElement Phn;


	@FindBy(css="#txtEmail")
	@CacheLookup
	WebElement emial;


	@FindBy(name="txtLLine")
	@CacheLookup
	WebElement landLine;


	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement address;

	@FindBy(name="rdbML")
	@CacheLookup
	WebElement Gender;


	public WebElement getApplicantName() {
		return applicantName;
	}


	public void setApplicantName(String applicantName) 
	{
		this.applicantName.sendKeys(applicantName);
	}


	public WebElement getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}


	public WebElement getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName); 
	}


	public WebElement getFatherName() {
		return fatherName;
	}


	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);	}


	public WebElement getDOB() {
		return DOB;
	}


	public void setDOB(String dOB) {
		this.DOB.sendKeys(dOB);
	}


	public WebElement getPhn() {
		return Phn;
	}


	public void setPhn(String phn) {
		this.Phn.sendKeys(phn); 
	}


	public WebElement getEmial() {
		return emial;
	}


	public void setEmial(String emial) {
		this.emial.sendKeys(emial);
	}


	public WebElement getLandLine() {
		return landLine;
	}


	public void setLandLine(String landLine) {
		this.landLine.sendKeys(landLine);
	}


	public WebElement getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public void register_gender(String Gender)
	{

		List<WebElement> radioElem = driver.findElements(By.name("rdbML"));

		for(WebElement webElement : radioElem)
		{
			String radioSelection;
			radioSelection = webElement.getAttribute("value").toString();
			if(radioSelection.equals("V1"))
			{
				webElement.click();
			}
		}

	}
	public void registe_Communication(String communication)
	{
		List<WebElement> radioElem = driver.findElements(By.name("rdbOffAddress"));

		for(WebElement webElement : radioElem)
		{
			String radioSelection;
			radioSelection = webElement.getAttribute("value").toString();
			if(radioSelection.equals("V1"))
			{
				webElement.click();
			}
		}
		
	}




}
