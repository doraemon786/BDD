package PageFactory1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class PersonPageFactory
{
	WebDriver driver;
	public PersonPageFactory(WebDriver driver)
	{
		super();
		this.driver=driver;
		PageFactory.initElements(driver, this);		
	}

	

	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;
	


	@FindBy(name="debit")
	@CacheLookup
	WebElement cardNumber;
	


	@FindBy(css="#txtCvv")
	@CacheLookup
	WebElement CVV;
	


	@FindBy(name="month")
	@CacheLookup
	WebElement expMonth;
	

	@FindBy(css="#txtYear")
	@CacheLookup
	WebElement expYear;
	
	public WebElement getCardHolderName() {
		return cardHolderName;
	}


	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}


	public WebElement getCardNumber() {
		return cardNumber;
	}


	public void setCardNumber(String cardNumber) {
		this.cardNumber.sendKeys(cardNumber);
	}


	public WebElement getCVV() {
		return CVV;
	}


	public void setCVV(String cVV) {
		this.CVV.sendKeys(cVV);
	}


	public WebElement getExpMonth() {
		return expMonth;
	}


	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth); 
	}


	public WebElement getExpYear() {
		return expYear;
	}


	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}
	
}
