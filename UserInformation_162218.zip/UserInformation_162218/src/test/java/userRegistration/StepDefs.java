package userRegistration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactory.UserPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	
	UserPageFactory page;
	WebDriver driver;
	
	
	@Given("^User Launches the Browser$")
	public void user_Launches_the_Browser() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		
		Thread.sleep(2000);
	
	}

	@When("^user enters the correct url$")
	public void user_enters_the_correct_url() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable 
	{
		
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		String result=driver.getTitle();
	
		System.out.println("The Verified Title is "+result);
		Thread.sleep(2000);
	}

	@When("^user enters the correct url and enter empty applicatant name$")
	public void user_enters_the_correct_url_and_enter_empty_applicatant_name() throws Throwable {
	

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	
	}
	
	@Then("^Show error message$")
	public void show_error_message() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String message=alert.getText();
		System.out.println(message);
		Thread.sleep(2000);
		driver.close();
		
	}

	@When("^user enters the correct url and enters First Name empty$")
	public void user_enters_the_correct_url_and_enters_First_Name_empty() throws Throwable {

		
		

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
		
	
	}

	@When("^user enters the correct url and enters Last Name empty$")
	public void user_enters_the_correct_url_and_enters_Last_Name_empty() throws Throwable {


		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	
	
	
	}

	@When("^user enters the correct url and enters Father name empty$")
	public void user_enters_the_correct_url_and_enters_Father_name_empty() throws Throwable {


		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	
	
	}

	@When("^user enters the correct url and enters Date of Birth empty$")
	public void user_enters_the_correct_url_and_enters_Date_of_Birth_empty() throws Throwable {


		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	
	
	}

	@When("^user enters the correct url and enters Gender empty$")
	public void user_enters_the_correct_url_and_enters_Gender_empty() throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@When("^user enters the correct url and enters Mobile Number empty$")
	public void user_enters_the_correct_url_and_enters_Mobile_Number_empty() throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@When("^user enters the correct url and enters MailId empty$")
	public void user_enters_the_correct_url_and_enters_MailId_empty() throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@When("^user enters the correct url and enters Landline empty$")
	public void user_enters_the_correct_url_and_enters_Landline_empty() throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@When("^user enters the correct url and enters Communication empty$")
	public void user_enters_the_correct_url_and_enters_Communication_empty() throws Throwable 
	{
		
		

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@When("^user enters the correct url and enters all the correct information$")
	public void user_enters_the_correct_url_and_enters_all_the_correct_information() throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/M3/UserInformation.html");
		page=new UserPageFactory(driver);
		page.setApplicantName("Harsh");
		page.setFirstName("Harsh");
		page.setLastName("Gautam");
		page.setFatherName("Arvind");
		page.setDOB("07-01-1996");
		page.register_gender("V1");
		page.setPhn("8860723885");
		page.setEmial("harshkumargautam96@gmail.com");
		page.setLandLine("02288779944");
		page.registe_Communication("V1");
		page.setAddress("Ghaziabad");
		driver.findElement(By.xpath("//*[@id=\"btnSubmit\"]")).click();
	}

	@Then("^show success message$")
	public void show_success_message() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String message=alert.getText();
		System.out.println(message);
		Thread.sleep(2000);
		driver.close();
		
	}

	@Then("^take user to the payment details page$")
	public void take_user_to_the_payment_details_page() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		Thread.sleep(2000);
		driver.close();
	}

}
