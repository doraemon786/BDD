package PersonDetails;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactory.UserPageFactory;
import PageFactory1.PersonPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{

	WebDriver driver;

	PersonPageFactory page;


	@Given("^User open the browser and open the url$")
	public void user_open_the_browser_and_open_the_url() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		Thread.sleep(2000);
	}

	@When("^Title is verified$")
	public void title_is_verified() throws Throwable
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		String result=driver.getTitle();
		System.out.println("The Verified Title is "+result);
		Thread.sleep(2000);

	}

	@Then("^Show success message$")
	public void show_success_message() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String message=alert.getText();
		System.out.println(message);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^CardHolder Name is empty$")
	public void cardholder_Name_is_empty() throws Throwable
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		page=new PersonPageFactory(driver);
		page.setCardHolderName("");
		page.setCardNumber("7894561232145678");
		page.setCVV("789");
		page.setExpMonth("01");
		page.setExpYear("2023");
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(2000);
	}

	@Then("^Show Error Message$")
	public void show_Error_Message() throws Throwable 
	{
		Alert alert=driver.switchTo().alert();
		String message=alert.getText();
		System.out.println(message);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^Debit Card number is empty$")
	public void debit_Card_number_is_empty() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		page=new PersonPageFactory(driver);
		page.setCardHolderName("Harsh");
		page.setCardNumber("");
		page.setCVV("789");
		page.setExpMonth("01");
		page.setExpYear("2023");
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(2000);
	}

	@When("^Debit Card Expiry month is empty$")
	public void debit_Card_Expiry_month_is_empty() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		page=new PersonPageFactory(driver);
		page.setCardHolderName("Harsh");
		page.setCardNumber("7894561232145678");
		page.setCVV("789");
		page.setExpMonth("");
		page.setExpYear("2023");
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(2000);
	}

	@When("^debit card expiry year is empty$")
	public void debit_card_expiry_year_is_empty() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		page=new PersonPageFactory(driver);
		page.setCardHolderName("Harsh");
		page.setCardNumber("7894561232145678");
		page.setCVV("789");
		page.setExpMonth("01");
		page.setExpYear("");
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(2000);
	}

	@When("^user enters all information correctly$")
	public void user_enters_all_information_correctly() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/M3/PaymentDetails.html");
		page=new PersonPageFactory(driver);
		page.setCardHolderName("Harsh");
		page.setCardNumber("7894561232145678");
		page.setCVV("789");
		page.setExpMonth("01");
		page.setExpYear("2023");
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(2000);
	}

	@Then("^Show Success page$")
	public void show_Success_page() throws Throwable
	{

		Alert alert=driver.switchTo().alert();
		String message=alert.getText();
		System.out.println(message);
		Thread.sleep(2000);
		driver.close();
	}



}
