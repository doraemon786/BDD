package package2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import package1.LoginPageFactory;

public class verifyapploginpagefactory {
	static String driverPath = "C:\\Users\\athomson"
			+ "\\Selenium Jar files-Fresh 2018\\";
	@Test
	public void veryfylogin()
	{
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/athomson/Documents"
				+ "/VnV/VNV%20Training%20materials/College%20Hire%20Training/Revamped%20Material_2018/Test%20Automation%20and%20Advanced%20Selenium/Class%20Demos/SeleniumWebDriverAT"
				+ "/SeleniumWebDriverAT/Lesson05/src/WorkingWithForms.html");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPageFactory login1 = new LoginPageFactory(driver);
		login1.login_misapp("alphy","alphy","alphy");
	//	login.typeusername();
		//login.typeconfirmpwd();
		
		
	}

}