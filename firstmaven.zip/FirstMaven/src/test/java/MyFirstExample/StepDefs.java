package MyFirstExample;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{


	@Given("^I have a wallet$")
	public void i_have_a_wallet() throws Throwable
	{
		System.out.println("This is Given");
		
	}

	@When("^That means i have some money$")
	public void that_means_i_have_some_money() throws Throwable 
	{
		System.out.println("This is When");
		
	}

	@Then("^I can lend you money$")
	public void i_can_lend_you_money() throws Throwable 
	{
		System.out.println("This is Then");
	}



}
