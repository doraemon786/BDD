package Two_Scenario;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},tags= {"@FirstScenario","@SecondExample"})
public class RunTestCukes {

}
