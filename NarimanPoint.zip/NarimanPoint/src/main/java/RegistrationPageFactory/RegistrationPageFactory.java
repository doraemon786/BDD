package RegistrationPageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory
{
	WebDriver driver;
	public RegistrationPageFactory(WebDriver driver)
	{
		super();
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(css="#txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"")
	@CacheLookup
	WebElement email;


	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	@CacheLookup
	WebElement phn;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement Address;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	WebElement city;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement state;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	WebElement numberOfGuest;
	

	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	@CacheLookup
	WebElement cardHolderName;
	

	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	@CacheLookup
	WebElement debitCardNumber;
	

	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	@CacheLookup
	WebElement CVV;
	
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement expiryMonth;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	@CacheLookup
	WebElement expiryYear;
	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(WebElement firstName) {
		this.firstName = firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(WebElement lastName) {
		this.lastName = lastName;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getPhn() {
		return phn;
	}

	public void setPhn(WebElement phn) {
		this.phn = phn;
	}

	public WebElement getAddress() {
		return Address;
	}

	public void setAddress(WebElement address) {
		Address = address;
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}

	public WebElement getState() {
		return state;
	}

	public void setState(WebElement state) {
		this.state = state;
	}

	public WebElement getNumberOfGuest() {
		return numberOfGuest;
	}

	public void setNumberOfGuest(WebElement numberOfGuest) {
		this.numberOfGuest = numberOfGuest;
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(WebElement cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public WebElement getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(WebElement debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public WebElement getCVV() {
		return CVV;
	}

	public void setCVV(WebElement cVV) {
		CVV = cVV;
	}

	public WebElement getExpiryMonth() {
		return expiryMonth;
	}

	public void setExpiryMonth(WebElement expiryMonth) {
		this.expiryMonth = expiryMonth;
	}

	public WebElement getExpiryYear() {
		return expiryYear;
	}

	public void setExpiryYear(WebElement expiryYear) {
		this.expiryYear = expiryYear;
	}
	
	

}
