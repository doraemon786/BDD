package registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{


	WebDriver driver;
	@Given("^User is no registration page$")
	public void user_is_no_registration_page() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/hotelbooking.html");
		Thread.sleep(2000);
	
	}

	@When("^user enters all the information correcly$")
	public void user_enters_all_the_information_correcly() throws Throwable 
	{
		pag=new 
	}

	@Then("^take user to the success page$")
	public void take_user_to_the_success_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^user enters some the information correcly$")
	public void user_enters_some_the_information_correcly() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^show error message$")
	public void show_error_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^user enter the wrong phone number$")
	public void user_enter_the_wrong_phone_number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^show error message(\\d+)$")
	public void show_error_message(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}



}
