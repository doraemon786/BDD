package login;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactory.LoginPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	LoginPageFactory page;
	@Given("^User open the browser and open the webpage$")
	public void user_open_the_browser_and_open_the_webpage() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/harsgaut/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();

	}

	@When("^Entered Url is correct$")
	public void entered_Url_is_correct() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/login.html");
	}


	@Then("^verify the heading$")
	public void verify_the_heading() throws Throwable
	{

		String heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		String expectedHeading="Hotel Booking Application";
		assertEquals(heading, expectedHeading);
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^user enter Username\"([^\"]*)\" only$")
	public void user_enter_Username_only(String arg1) throws Throwable
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/login.html");
		page=new LoginPageFactory(driver);
		page.setUsername(arg1);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#mainCnt > div > div:nth-child(1) > form > table > tbody > tr:nth-child(4) > td:nth-child(2) > input")).click();
		Thread.sleep(2000);
		String emptyPassword=driver.findElement(By.cssSelector("#pwdErrMsg")).getText();
		System.out.println("Provided Message is "+emptyPassword);
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^user enter Password\"([^\"]*)\"$")
	public void user_enter_Password(String arg1) throws Throwable 
	{

		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/login.html");
		page=new LoginPageFactory(driver);
		page.setPassword(arg1);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#mainCnt > div > div:nth-child(1) > form > table > tbody > tr:nth-child(4) > td:nth-child(2) > input")).click();
		Thread.sleep(2000);
		String emptyUsername=driver.findElement(By.cssSelector("#userErrMsg")).getText();
		System.out.println("Provided Message is "+emptyUsername);
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^user enters correct username\"([^\"]*)\" and correct password\"([^\"]*)\"$")
	public void user_enters_correct_username_and_correct_password(String arg1, String arg2) throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/login.html");
		page=new LoginPageFactory(driver);
		page.setUsername(arg1);
		page.setPassword(arg2);
		driver.findElement(By.cssSelector("#mainCnt > div > div:nth-child(1) > form > table > tbody > tr:nth-child(4) > td:nth-child(2) > input")).click();
		Thread.sleep(2000);
	}

	@Then("^verify the title$")
	public void verify_the_title() throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/hotelbooking.html");
		String result=driver.getTitle();
		String actualTitle="Hotel Booking";
		assertEquals(actualTitle,result);
		System.out.println(result);
		Thread.sleep(2000);
		driver.close();

	}

	@Then("^user enters incorrect username\"([^\"]*)\" and incorrect password\"([^\"]*)\"$")
	public void user_enters_incorrect_username_and_incorrect_password(String arg1, String arg2) throws Throwable 
	{
		driver.get("file:///C:/Users/harsgaut/Desktop/BDD/login.html");
		page=new LoginPageFactory(driver);
		page.setUsername(arg1);
		page.setPassword(arg2);
		driver.findElement(By.cssSelector("#mainCnt > div > div:nth-child(1) > form > table > tbody > tr:nth-child(4) > td:nth-child(2) > input")).click();
		Thread.sleep(2000);
		driver.close();
	}
}
