package MySecondExample;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {


@Given("^User launches the browser and opens the application$")
public void user_launches_the_browser_and_opens_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  
}

@When("^User enters the valid username and valid password$")
public void user_enters_the_valid_username_and_valid_password(DataTable arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
    // E,K,V must be a scalar (String, Integer, Date, enum etc)
    
}

@When("^Clicks on Sign$")
public void clicks_on_Sign() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
 
}

@Then("^Application takes to the 'Hotel booking' page$")
public void application_takes_to_the_Hotel_booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}


}
