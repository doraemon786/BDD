package Background_Example;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefs {


@Given("^Clear the already created users before starting scenario$")
public void clear_the_already_created_users_before_starting_scenario() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@Given("^I have opened the Development Site$")
public void i_have_opened_the_Development_Site() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}

@Given("^I see the home page loaded$")
public void i_see_the_home_page_loaded() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}

@When("^I click the register link$")
public void i_click_the_register_link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}

@Then("^I should the register page$")
public void i_should_the_register_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
 
}

@Then("^I fill the form with details$")
public void i_fill_the_form_with_details(DataTable arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
    // E,K,V must be a scalar (String, Integer, Date, enum etc)

}


}
