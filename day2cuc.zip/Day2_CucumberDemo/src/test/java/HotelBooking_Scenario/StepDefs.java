package HotelBooking_Scenario;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {


@Given("^User launches the browser and opens the application$")
public void user_launches_the_browser_and_opens_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}

@Given("^User has the valid username and password$")
public void user_has_the_valid_username_and_password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}

@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
public void user_enters_the_and(String arg1, String arg2) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}

@Then("^Application takes to the 'Hotel booking' page$")
public void application_takes_to_the_Hotel_booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    
}
}
