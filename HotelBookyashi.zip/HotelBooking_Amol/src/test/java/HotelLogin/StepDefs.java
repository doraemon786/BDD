package HotelLogin;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LoginPageFactory.LoginPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefs {

	WebDriver driver;
	LoginPageFactory page;

	@Given("^User launch the browser$")
	public void user_launch_the_browser() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:/Yashi/chromedriver/chromedriver.exe");
		driver=new ChromeDriver();
	}

	@When("^Open the login html page$")
	public void open_the_login_html_page() throws Throwable {

		driver.get("file:///C:/Users/ysinha/Desktop/BDD/BDD/login.html" );
	}

	@Then("^Verify the heading of the login page$")
	public void verify_the_heading_of_the_login_page() throws Throwable {
		String heading= driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		assertEquals("Hotel Booking Application", heading);
		System.out.println(heading);
		driver.close();
	}

	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Yashi/chromedriver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/ysinha/Desktop/BDD/BDD/login.html" );
	}

	@When("^If username and password are empty$")
	public void if_username_and_password_are_empty() throws Throwable {
		page=new LoginPageFactory(driver);
		page.setUsername("");
		page.setPassword("");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(2000);
	}

	@Then("^Display error msg$")
	public void display_error_msg() throws Throwable
	{
		String errorUserName=driver.findElement(By.id("userErrMsg")).getText();
		System.out.println(errorUserName);
		Thread.sleep(2000);
		driver.close();

	}

	@When("^If username is empty$")
	public void if_username_is_empty() throws Throwable {
		page=new LoginPageFactory(driver);
		page.setUsername("");
		page.setPassword("Bhatnagar");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(5000);
	}

	@Then("^Show error msg$")
	public void show_error_msg() throws Throwable {
		String error=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		assertEquals("* Please enter userName.", error);
		System.out.println(error);
		driver.close();

	}

	@When("^If password is empty$")
	public void if_password_is_empty() throws Throwable {

		page=new LoginPageFactory(driver);
		page.setUsername("Aakarsh");
		page.setPassword("");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(5000);
	}

	@Then("^Show error text$")
	public void show_error_text() throws Throwable {
		String error=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		assertEquals("* Please enter password.", error);
		System.out.println(error);
		driver.close();

	}

	@Given("^user enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:/Yashi/chromedriver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/ysinha/Desktop/BDD/BDD/login.html" );
		page=new LoginPageFactory(driver);
		page.setUsername("capgemini");
		page.setPassword("capg1234");
	}

	@When("^Click on login$")
	public void click_on_login() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^Application takes to the 'Hotel Booking' page$")
	public void application_takes_to_the_Hotel_Booking_page() throws Throwable {
		String heading=driver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form", heading);
		System.out.println(heading);
		driver.close();

	}
	
	@Given("^user enters the incorrect \"([^\"]*)\" and \"([^\"]*)\"$")
public void user_enters_the_incorrect_and(String arg1, String arg2) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Yashi/chromedriver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/ysinha/Desktop/BDD/BDD/login.html" );
		page=new LoginPageFactory(driver);
		page.setUsername("yashi");
		page.setPassword("ysinha");
}

@Then("^Display error text$")
public void display_error_text() throws Throwable {
	
	Alert alert=driver.switchTo().alert();
	System.out.println("The alert message is : " + alert.getText());
	
	Thread.sleep(2500);
	driver.quit();
	
}

}
