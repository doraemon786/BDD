package com.cg.pgfc;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryReg {
	WebDriver driver;
	public PageFactoryReg(WebDriver driver)
	{
		this.driver=driver;
		  PageFactory.initElements(driver, this);
	}
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement fstname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lstname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement formcity;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement formstate;
	
	@FindBy(name="persons")
	@CacheLookup
	WebElement formnoofpersons;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardholder;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitnumber;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expirationmonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement expirationyear;
	
	@FindBy(how=How.XPATH,using="/html/body/h1")
	@CacheLookup
	WebElement successmsg;
	
	public String getsuccessmsg()
	{
		return successmsg.getText();
	}
	
	public WebElement getFormdebitCardno() {
		return debitnumber;
	}

	public void setFormdebitCardno(String debitCardno)
	{
		this.debitnumber.sendKeys(debitCardno);
	}

	public WebElement getFormCVV() {
		return cvv;
	}

	public void setFormCVV(String CVV) {
		this.cvv.sendKeys(CVV);
	}

	public WebElement getFormexpmonth() {
		return expirationmonth;
	}

	public void setFormexpmonth(String expmonth) {
		this.expirationmonth.sendKeys(expmonth);
	}

	public WebElement getFormexpyear() {
		return expirationyear;
	}

	public void setFormexpyear(String expyear) {
		this.expirationyear.sendKeys(expyear);
	}
	
	public WebElement getFormcardholdername() {
		return cardholder;
	}

	public void setFormcardholdername(String cardholdername) {
		this.cardholder.sendKeys(cardholdername);
	}

	public WebElement getFormfirstname() {
		return fstname;
	}

	public void setFormfirstname(String firstname) 
	{
		fstname.sendKeys(firstname);	
		
	}	
	
	public WebElement getFormlastname() {
		return lstname;
	}

	public void setFormlastname(String lastname) {
		lstname.sendKeys(lastname);
	}

	public WebElement getFormemail() {
		return email;
	}

	public void setFormemail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getFormfone() {
		return phone;
	}

	public void setFormfone(String fone) {
		this.phone.sendKeys(fone);
	}

	public WebElement getFormaddress() {
		return address;
	}

	public void setFormaddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getFormcity() {
		return formcity;
	}

	public void setFormcity(String city) 
	{
		Select cityobj= new Select(formcity);
		cityobj.selectByVisibleText(city);
	}

	public WebElement getFormstate() {
		return formstate;
	}

	public void setFormstate(String state) 
	{
		Select stateobj= new Select(formstate);
		stateobj.selectByValue(state);
	}

	public WebElement getFormnoofpersons() {
		return formnoofpersons;
	}

	public void setFormnoofpersons(String noofpersons) {
		this.formnoofpersons.sendKeys(noofpersons);
	}

}
