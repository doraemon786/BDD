package com.cg.pgfc;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryLog {
	WebDriver driver;
	public PageFactoryLog(WebDriver driver)
	{
		this.driver=driver;
		  PageFactory.initElements(driver, this);
	}
	@FindBy(name="userName")
	@CacheLookup
	WebElement usrname;
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement passwrd;
	
	public void setusrnme(String username)
	{
		usrname.sendKeys(username);
	}
	public WebElement getusrnme()
	{
		return usrname;
	}
	public void setpass(String password)
	{
		passwrd.sendKeys(password);
	}
	public WebElement getpass()
	{
		return passwrd;
	}
}
