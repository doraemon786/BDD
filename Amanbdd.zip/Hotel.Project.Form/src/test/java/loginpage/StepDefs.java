package loginpage;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.cg.pgfc.PageFactoryLog;
public class StepDefs {
	ChromeDriver driver;
	PageFactoryLog pf;
	@Given("^User open the browser$")
	public void user_open_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/amaagnih/Desktop/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@When("^the url is correct to open the browser$")
	public void the_url_is_correct_to_open_the_browser() throws Throwable {
		driver.get("file:////C:/Users/amaagnih/Desktop/BDD/login.html");
	}

	@Then("^click on login page$")
	public void click_on_login_page() throws Throwable {
    String heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
    assertEquals("Hotel Booking Application", heading);
    System.out.println(heading);
    Thread.sleep(1000);
    driver.close();
	}



@Given("^user opens the application$")
public void user_opens_the_application() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:/Users/amaagnih/Desktop/chromedriver_win32/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("file:////C:/Users/amaagnih/Desktop/BDD/login.html");
	pf=new PageFactoryLog(driver);
}
@When("^user enters valid username and validpassword$")
public void user_enters_valid_username_and_validpassword() throws Throwable {
	pf.setusrnme("capgemini");
	pf.setpass("capg1234");
}
@When("^user enters correct username and password$")
public void user_enters_correct_username_and_password(String arg1,String arg2) throws Throwable {
driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input")).sendKeys("capgemini");
driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input")).sendKeys("capg1234");
pf.setusrnme(arg1);
pf.setpass(arg2);
}

@When("^Clicks on Login button$")
public void clicks_on_Login_button() throws Throwable {
driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
}

@Then("^Application takes to the 'Hotel booking' page$")
public void application_takes_to_the_Hotel_booking_page() throws Throwable {
    String heading=driver.findElement(By.xpath("/html/body/div/h2")).getText();
    assertEquals("Hotel Booking Form", heading);
    System.out.println(heading);
    Thread.sleep(1000);
    driver.close();
}
@Given("^User launches the browser and opens the application$")
public void user_launches_the_browser_and_opens_the_application() throws Throwable {
	driver = new ChromeDriver();
	driver.get("file:////C:/Users/amaagnih/Desktop/BDD/login.html");
	pf=new PageFactoryLog(driver);
}

@When("^User enters the invalid username or invalid password$")
public void user_enters_the_invalid_username_or_invalid_password() throws Throwable {
	pf.setusrnme("capgemin");
	pf.setpass("capg123");
	driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	   Thread.sleep(1000);
	   driver.close();
}

/*@Then("^show error message$")
public void show_error_message() throws Throwable {
	   String errmsg= driver.findElement(By.id("")).getText();
	   String experrmsg="Invalid login! Please try again!";
	   assertEquals(errmsg,experrmsg);
	   Thread.sleep(1000);
	   driver.close();
}*/
@When("^User enters the no username and no password$")
public void user_enters_the_no_username_and_no_password() throws Throwable {
	pf.setusrnme("");
	pf.setpass("");
	driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
}
@Then("^show error message no username$")
public void show_error_message_no_username() throws Throwable {
	   String errmsg1= driver.findElement(By.id("userErrMsg")).getText();
	   String experrmsg1="* Please enter userName.";
	   assertEquals(errmsg1,experrmsg1);
	   System.out.println(errmsg1);
	   Thread.sleep(1000);
	   driver.close();
}


@When("^User enters the username and no password$")
public void user_enters_the_username_and_no_password() throws Throwable {
	pf.setusrnme("capgemini");
	pf.setpass("");
	driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	
}

@Then("^show error message no password$")
public void show_error_message_no_password() throws Throwable {
	   String errmsg2= driver.findElement(By.id("pwdErrMsg")).getText();
	   String experrmsg2="* Please enter password.";
	   assertEquals(errmsg2,experrmsg2);
	   System.out.println(errmsg2);
	   Thread.sleep(1000);
	   driver.close();
}

}
