package registrationpage;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.cg.pgfc.PageFactoryReg;
public class StepDefs {
	ChromeDriver driver;
	PageFactoryReg pagefact;
	@Given("^User open the browser$")
	public void user_open_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/amaagnih/Desktop/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@When("^the url is correct to open the browser$")
	public void the_url_is_correct_to_open_the_browser() throws Throwable {
		driver.get("file:////C:/Users/amaagnih/Desktop/BDD/hotelbooking.html");
	}

	@Then("^click on registration page$")
	public void click_on_registration_page() throws Throwable {
	    String heading=driver.findElement(By.xpath("/html/body/div/h2")).getText();
	    assertEquals("Hotel Booking Form", heading);
	    System.out.println(heading);
	    Thread.sleep(1000);
	    driver.close();
	}

@Given("^User opens the application$")
public void user_opens_the_application() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:/Users/amaagnih/Desktop/chromedriver_win32/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("file:////C:/Users/amaagnih/Desktop/BDD/hotelbooking.html");
	pagefact= new PageFactoryReg(driver);
}

@When("^User fill the form$")
public void user_fill_the_form() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@When("^Click on 'Confirm Booking'$")
public void click_on_Confirm_Booking() throws Throwable {
driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
}

@Then("^Application takes to the 'success page'$")
public void application_takes_to_the_success_page() throws Throwable {
    String heading=driver.findElement(By.xpath("/html/body/h1")).getText();
    assertEquals("Booking Completed!", heading);
    System.out.println(heading);
    Thread.sleep(1000);
    driver.close();
}
@Given("^User is on the booking form$")
public void user_is_on_the_booking_form() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:/Users/amaagnih/Desktop/chromedriver_win32/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("file:////C:/Users/amaagnih/Desktop/BDD/hotelbooking.html");
	pagefact= new PageFactoryReg(driver);
}

@When("^first name is not entered$")
public void first_name_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@When("^Clicks on 'Confirm booking'$")
public void clicks_on_Confirm_booking() throws Throwable {
	driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
}

@Then("^Show error message first name is not there$")
public void show_error_message_first_name_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill the First Name";
     
   driver.switchTo().alert().accept();
    System.out.println(expectedmsg);
  
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}

@When("^last name is not entered$")
public void last_name_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@Then("^Show error message last name is not there$")
public void show_error_message_last_name_is_not_there() throws Throwable {
	
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill the Last Name";
     
  System.out.println(expectedmsg);
   driver.close();
   assertEquals(actualmsg,expectedmsg);
}

@When("^email is not entered$")
public void email_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@Then("^Show error message email is not there$")
public void show_error_message_email_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill the Email";
     
  System.out.println(expectedmsg);
   
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}

@When("^mobile number is not entered$")
public void mobile_number_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@Then("^Show error message mobile number is not there$")
public void show_error_message_mobile_number_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill the Mobile No.";
     
  System.out.println(expectedmsg);
  
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}

@When("^expiration year is not entered$")
public void expiration_year_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("");
}

@Then("^Show error message expiration is not there$")
public void show_error_message_expiration_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill the expiration year";
     
  System.out.println(expectedmsg);
   
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}

@When("^expiration month is not entered$")
public void expiration_month_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Bangalore");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("");
	pagefact.setFormexpyear("2020");
}

@Then("^Show error message expiration month is not there$")
public void show_error_message_expiration_month_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please fill expiration month";
     
  System.out.println(expectedmsg);
 
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}
@When("^city is not entered$")
public void city_is_not_entered() throws Throwable {
	pagefact.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefact.setFormlastname("Thomson");
	pagefact.setFormemail("abc@gmail.com");
	pagefact.setFormfone("9234567890");
	pagefact.setFormaddress("Whitefield,Bangalore");
	pagefact.setFormcity("Select City");
	pagefact.setFormstate("Karnataka");
	pagefact.setFormnoofpersons("3");
	pagefact.setFormcardholdername("Alphy T");
	pagefact.setFormdebitCardno("13459045872");
	pagefact.setFormCVV("123");
	pagefact.setFormexpmonth("Jan");
	pagefact.setFormexpyear("2020");
}

@Then("^Show error message city is not there$")
public void show_error_message_city_is_not_there() throws Throwable {
    String actualmsg=driver.switchTo().alert().getText();
    String expectedmsg="Please select city";
     
  System.out.println(expectedmsg);
 
   assertEquals(actualmsg,expectedmsg);
   Thread.sleep(1000);
   driver.close();
}

}
