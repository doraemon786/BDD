package hotelBooking;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageFactory.LoginPageFactory;


public class StepDefs {

	WebDriver driver;
	LoginPageFactory page;
	
	@Given("^Launch the browser$")
	public void launch_the_browser() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
	}

	@When("^Open login\\.html page$")
	public void open_login_html_page() throws Throwable 
	{
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/login.html\r\n" );
	}

	@Then("^Verify Heading$")
	public void verify_Heading() throws Throwable
	{
		String heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		assertEquals("Hotel Booking Application", heading);
		System.out.println(heading);
		driver.close();
	}
	
	@Given("^Enter UserName as empty$")
	public void enter_UserName_as_empty() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/login.html\r\n" );
		page=new LoginPageFactory(driver);
		page.setUserName("");
	  
		
	}

	@When("^If username is empty$")
	public void if_username_is_empty() throws Throwable {
	
		   driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		   Thread.sleep(5000);
		 
	}

	@Then("^Show error msg$")
	public void show_error_msg() throws Throwable {
	 String error=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
	 assertEquals("* Please enter userName.",error);
	 System.out.println(error);
	 driver.close();
	}
	
	
	@Given("^Enter username and Enter Password as empty$")
	public void enter_username_and_Enter_Password_as_empty() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/login.html\r\n" );
		page=new LoginPageFactory(driver);
		page.setUserName("Aakarsh");
		page.setPassword("");
	}

	@When("^If password is Empty$")
	public void if_password_is_Empty() throws Throwable {
		  driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		   Thread.sleep(5000);
	}
	@Then("^Show the error msg$")
	public void show_the_error_msg() throws Throwable {
		 String error=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		 assertEquals("* Please enter password.",error);
		 driver.close();
	}
	
	@Given("^user enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/login.html\r\n" );
		page=new LoginPageFactory(driver);
		page.setUserName("capgemini");
		page.setPassword("capg1234");
	}

	@When("^Click on login$")
	public void click_on_login() throws Throwable {
		  driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^Application takes to the 'Hotel Booking' page$")
	public void application_takes_to_the_Hotel_Booking_page() throws Throwable {
	  String head=driver.findElement(By.xpath("/html/body/div/h2")).getText();
	  assertEquals("Hotel Booking Form", head);
	  System.out.println(head);
	  driver.close();
	}
	
	


	
	



}
