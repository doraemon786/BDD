package registration;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import RegistrationPageFactory.RegisterPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
	WebDriver driver;
	RegisterPageFactory page;
	@Given("^User enters all details correctly$")
	public void user_enters_all_details_correctly() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/hotelbooking.html\r\n" );
		page=new RegisterPageFactory(driver);
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setEmail("aaka.bhat@gmail.com");
		String[] city= {"Pune","Bangalore","Chennai"};
		page.register_city(city);
		String[] state= {"Maharashtra","Tamilnadu","Telangana"};
		page.register_state(state);
		page.register_person("4");
		page.setMobile("9044964433");
		page.setAddress("Lucknow");
		page.setCardHolderName("Aakarsh Bhatnagar");
		page.setDebitCardHolderName("Aayushi Bhatnagar");
		page.setCvv("987");
		page.setExpMonth("january");
		page.setExpYear("2023");
		
	}

	@When("^Click on Confirm Booking$")
	public void click_on_Confirm_Booking() throws Throwable {
	  page.ClickBtn();
	}

	@Then("^Verify if page displays Booking Completed$")
	public void verify_if_page_displays_Booking_Completed() throws Throwable {
	    String heading=driver.findElement(By.xpath("/html/body/h1")).getText();
	    assertEquals("Booking Completed!", heading);
	    System.out.println(heading);
		driver.close();
	}
	

	@Given("^Launch the browser and open the application$")
	public void launch_the_browser_and_open_the_application() throws Throwable {
  
		System.setProperty("webdriver.chrome.driver", "C:/Users/aakbhatn/Desktop/chromedriver_win32/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/aakbhatn/Desktop/BDD%20case%20study/hotelbooking.html\r\n" );
		page=new RegisterPageFactory(driver);
	}

	@When("^User enters some incorrect details$")
	public void user_enters_some_incorrect_details() throws Throwable {
		
		page.setFirstname("Aakarsh");
		page.setLastname("");
		page.setEmail("aaka.bhat@gmail.com");
		String[] city= {"Pune","Bangalore","Chennai"};
		page.register_city(city);
		String[] state= {"Maharashtra","Tamilnadu","Telangana"};
		
		page.register_state(state);
		page.register_person("4");
		page.setMobile("9044964433");
		page.setAddress("Lucknow");
		page.setCardHolderName("Aakarsh Bhatnagar");
		page.setDebitCardHolderName("Aayushi Bhatnagar");
		page.setCvv("987");
		page.setExpMonth("january");
		page.setExpYear("2023");
		page.ClickBtn(); 
		
		
		
	}

	@Then("^show error and display alert messages$")
	public void show_error_and_display_alert_messages() throws Throwable {
	
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please fill the Last Name", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		Thread.sleep(2000);
		alert.accept();
		driver.close();
	}
	
	@When("^User enters incorrect email id$")
	public void user_enters_incorrect_email_id() throws Throwable {
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setEmail("aaka.bhatgmail.com");
		String[] city= {"Pune","Bangalore","Chennai"};
		page.register_city(city);
		String[] state= {"Maharashtra","Tamilnadu","Telangana"};
		page.register_state(state);
		page.register_person("3");
		page.setMobile("9044964433");
		page.setAddress("Lucknow");
		page.setCardHolderName("Aakarsh Bhatnagar");
		page.setDebitCardHolderName("Aayushi Bhatnagar");
		page.setCvv("987");
		page.setExpMonth("january");
		page.setExpYear("2023");
		page.ClickBtn(); 
		
	}

	@Then("^show error and display invalid email message$")
	public void show_error_and_display_invalid_email_message() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please enter valid Email Id.", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		Thread.sleep(2000);
		alert.accept();
		driver.close();
	}

	@When("^User enters incorrect mobile no$")
	public void user_enters_incorrect_mobile_no() throws Throwable {
		page.setFirstname("Aakarsh");
		page.setLastname("Bhatnagar");
		page.setEmail("aaka.bhat@gmail.com");
		String[] city= {"Pune","Bangalore","Chennai"};
		page.register_city(city);
		String[] state= {"Maharashtra","Tamilnadu","Telangana"};
		page.register_state(state);
		page.register_person("3");
		page.setMobile("asda");
		page.setAddress("Lucknow");
		page.setCardHolderName("Aakarsh Bhatnagar");
		page.setDebitCardHolderName("Aayushi Bhatnagar");
		page.setCvv("987");
		page.setExpMonth("january");
		page.setExpYear("2023");
		page.ClickBtn(); 
	}

	@Then("^show error and display invalid mob message$")
	public void show_error_and_display_invalid_mob_message() throws Throwable {
		Alert alert=driver.switchTo().alert();
		String alertMsg = alert.getText();
		assertEquals("Please enter valid Contact no.", alertMsg);
		System.out.println("The alert message is : " + alertMsg);
		Thread.sleep(2000);
		alert.accept();
		driver.close();
	} 




}
