

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class verifyapploginpagefactory {

	@Test
	public void veryfylogin()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/debjchow/Desktop/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/debjchow/Downloads/WorkingWithForms.html");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPageFactory login1 = new LoginPageFactory(driver);
		login1.login_misapp("alphy","alphy","alphy","Priyodarshini","Roy","Female","13-12-1997","priyo197@gmail.com","Malda","Pune","Mumbai","8436127859","Music","Reading");
	//	login.typeusername();
		//login.typeconfirmpwd();
		
		
	}

}