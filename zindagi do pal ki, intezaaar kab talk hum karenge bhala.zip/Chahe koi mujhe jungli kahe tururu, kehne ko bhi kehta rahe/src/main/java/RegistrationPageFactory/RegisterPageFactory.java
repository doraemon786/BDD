package RegistrationPageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPageFactory {

	WebDriver driver;
	public RegisterPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"txtFirstName\"]")
	@CacheLookup
	WebElement firstname;
	
	@FindBy(xpath="//*[@id=\"txtLastName\"]")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement address;
	
	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	@CacheLookup
	WebElement cardHolderName;
	
	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	@CacheLookup
	WebElement debitCardHolderName;
	
	
	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement expMonth;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	@CacheLookup
	WebElement expYear;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement submit;
	
	
	

	@FindBy(name="city")
	@CacheLookup
	WebElement City;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement State;
	
	@FindBy(name="persons")
	@CacheLookup
	WebElement Person;
	

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String username) {
		this.firstname.sendKeys(username);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public WebElement getDebitCardHolderName() {
		return debitCardHolderName;
	}

	public void setDebitCardHolderName(String debitCardHolderName) {
		this.debitCardHolderName.sendKeys(debitCardHolderName);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public WebElement getExpYear() {
		return expYear;
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}
	
	public void ClickBtn() {
		
		submit.click();
	}
	
	public void register_city(String[] city)
    {
        Select cty = new Select(City);
    for(int i=0;i<city.length;i++)
    {
    	cty.selectByValue(city[i]);
    	
    }
  
    }
	
	public void register_state(String[] state)
    {
        Select ste = new Select(State);
    for(int i=0;i<state.length;i++)
    {
    	ste.selectByValue(state[i]);
    }
  
    }
	
	  
    public void register_person(String person)
       {
           Select per = new Select(Person);
           per.selectByValue(person);
       }
	
	
	
	
	
	
	
	
	
}
