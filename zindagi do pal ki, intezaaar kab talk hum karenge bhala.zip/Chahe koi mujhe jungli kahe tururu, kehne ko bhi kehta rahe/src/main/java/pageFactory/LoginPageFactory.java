package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {


	WebDriver driver;

	public LoginPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input")
	@CacheLookup
	WebElement username;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement password;
	



	public WebElement getPassword() {
		return password;
	}



	public void setPassword(String pass) {
		password.sendKeys(pass);
	}



	public WebElement getUsername() {
		return username;
	}



	public void setUserName(String uname) {
		
		username.sendKeys(uname);
	}
}
